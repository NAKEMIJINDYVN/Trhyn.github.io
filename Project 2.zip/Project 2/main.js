const sildes=document.getElementById('sildes')
const left=document.getElementById("left")
const right=document.getElementById('right')
const carouselimage=document.querySelectorAll('.carousel-image')
let currentimage=0
function showimage(){
    const imagewith=carouselimage[0].clientWidth;
    sildes.style.transform=`translateX(${-currentimage * imagewith}px)`
}

left.addEventListener('click', ()=>{
    if(currentimage>0){
        currentimage--;
        showimage()
    }
})

right.addEventListener('click',()=>{
    if(currentimage<carouselimage.length-1){
        currentimage++;
        showimage()

    }
})